package com.online.bank.util;

public enum AccountStatus {

	ACTIVE,INACTIVE
}
